from datetime import datetime  
import time 
print(datetime.time(datetime.now()))
print(datetime.time(datetime.utcnow()))
print(time.tzname)
print(time.timezone / 3600)
