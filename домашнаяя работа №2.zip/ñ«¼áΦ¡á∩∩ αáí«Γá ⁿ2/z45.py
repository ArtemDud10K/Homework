import difflib
import time

x = SequenceMatcher(a=text1, b=text2)
