list1 = [1, 2, 3, 4, 5]
mini = min(list1)#выбор минимального
list1.remove(mini)#удаление минимального
mini1 = min(list1)# выболр минимального в новом списке
print(mini1)
