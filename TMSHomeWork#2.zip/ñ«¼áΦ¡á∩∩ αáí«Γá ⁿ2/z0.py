number = float(input('Введите число\n'))
if number < 100 and number > 0: #задание числового диапазона
	print('Число в нужном диапозоне')
else:
	print('Вы вышли за диапазон')
