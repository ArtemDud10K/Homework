number = int(input('Введите число от 0 до 50\n'))
if number % 3 == 0:
	print('Foo')
if number % 5 == 0:
	print('Bar')
