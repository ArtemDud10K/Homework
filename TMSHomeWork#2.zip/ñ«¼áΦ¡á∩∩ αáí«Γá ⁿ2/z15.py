L1 = [4, 2, 1, 4, 5]
L2 = [8, 2, 6, 8, 5]
if len(L1) == len(L2):
	print('по длинне равны') 
l1 = set(L1)
l2 = set(L2)
print('разница'l1^l2)
