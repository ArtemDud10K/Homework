import random as r
A = int(input('Введите левую границу промежутка\n'))
B = int(input('Введите правую границу промежутка\n'))
print('Ваше число:', r.randint(A, B))#вывод рандомного числа
