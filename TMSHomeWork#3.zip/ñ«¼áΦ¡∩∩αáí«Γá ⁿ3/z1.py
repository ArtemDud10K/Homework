num = int(input('Введите число, до которого вы будете суммировать\n'))
sum1 = 0
for i in range(num + 1):
	sum1 += i
print('Результат суммирования:', sum1)
