d = {'21': 'a', '12': 'b', '45': 'c'}
for i in d:
	print(i ,d[i])
